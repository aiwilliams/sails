//$Id: AssertTrueValidator.java,v 1.2 2005/08/11 19:45:28 epbernard Exp $
package org.hibernate.validator;


/**
 * Check whether an element is true or not
 *
 * @author Gavin King
 */
public class AssertTrueValidator implements Validator<AssertTrue> {

	public boolean isValid(Object value) {
		return (Boolean) value;
	}

	public void initialize(AssertTrue parameters) {
	}

}
