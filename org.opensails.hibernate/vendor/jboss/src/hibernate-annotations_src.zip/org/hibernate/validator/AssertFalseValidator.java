//$Id: AssertFalseValidator.java,v 1.2 2005/08/11 19:45:28 epbernard Exp $
package org.hibernate.validator;


/**
 * Check if a given object is false or not
 *
 * @author Gavin King
 */
public class AssertFalseValidator implements Validator<AssertFalse> {

	public boolean isValid(Object value) {
		return !(Boolean) value;
	}

	public void initialize(AssertFalse parameters) {
	}

}
