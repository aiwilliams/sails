//$Id: MapBinder.java,v 1.8 2005/09/05 10:34:55 epbernard Exp $
package org.hibernate.cfg.annotations;

import java.lang.reflect.AnnotatedElement;
import java.util.Map;

import org.hibernate.AnnotationException;
import org.hibernate.FetchMode;
import org.hibernate.MappingException;
import org.hibernate.cfg.BinderHelper;
import org.hibernate.cfg.CollectionSecondPass;
import org.hibernate.cfg.Ejb3Column;
import org.hibernate.cfg.Ejb3JoinColumn;
import org.hibernate.cfg.ExtendedMappings;
import org.hibernate.cfg.SecondPass;
import org.hibernate.mapping.Collection;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;

/**
 * Implementation to bind a Map
 *
 * @author Emmanuel Bernard
 */
public class MapBinder extends CollectionBinder {

	protected Collection createCollection(PersistentClass persistentClass) {
		return new org.hibernate.mapping.Map( persistentClass );
	}

	@Override
	public SecondPass getSecondPass(
			final Ejb3JoinColumn[] fkJoinColumns, final Ejb3JoinColumn[] keyColumns,
			final Ejb3JoinColumn[] inverseColumns,
			final Ejb3Column[] elementColumns,
			final boolean isEmbedded,
			final AnnotatedElement annotatedElt, final String collType,
			final FetchMode fetchMode, final boolean ignoreNotFound, final boolean unique,
			final ExtendedMappings mappings
	) {
		return new CollectionSecondPass( mappings, MapBinder.this.collection ) {
			public void secondPass(Map persistentClasses, Map inheritedMetas)
					throws MappingException {
				bindStarToManySecondPass(
						persistentClasses, collType, fkJoinColumns, keyColumns, inverseColumns, elementColumns,
						isEmbedded, annotatedElt, fetchMode, unique, mappings, ignoreNotFound
				);
				bindKeyFromAssociationTable( collType, persistentClasses, mapKeyPropertyName, mappings );
			}
		};
	}

	private void bindKeyFromAssociationTable(
			String collType, Map persistentClasses, String mapKeyPropertyName, ExtendedMappings mappings
	) {
		if ( mapKeyPropertyName == null ) throw new AnnotationException( "A Map must declare a @MapKey element" );
		PersistentClass associatedClass = (PersistentClass) persistentClasses.get( collType );
		if ( associatedClass == null ) throw new AnnotationException( "Associated class not found: " + collType );
		Property property = BinderHelper.findPropertyByName( associatedClass, mapKeyPropertyName );
		if ( property == null ) {
			throw new AnnotationException(
					"Map key property not found: " + collType + "." + mapKeyPropertyName
			);
		}
		org.hibernate.mapping.Map map = (org.hibernate.mapping.Map) this.collection;
		map.setIndex( property.getValue() );
	}
}
