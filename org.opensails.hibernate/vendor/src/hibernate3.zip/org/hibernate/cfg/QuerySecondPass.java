//$Id: QuerySecondPass.java,v 1.1 2006/01/11 18:50:32 epbernard Exp $
package org.hibernate.cfg;

/**
 * Bind query
 *
 * @author Emmanuel Bernard
 */
public interface QuerySecondPass extends SecondPass {
}
