//$Id: ValidatePreInsertEventListener.java,v 1.4 2005/08/11 19:45:28 epbernard Exp $
package org.hibernate.validator.event;

/**
 * Before update, execute the validator framework
 *
 * @author Gavin King
 */
public class ValidatePreInsertEventListener extends ValidateEventListener {

}
