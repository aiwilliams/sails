//$Id: InheritanceState.java,v 1.10 2006/01/05 13:49:51 epbernard Exp $
package org.hibernate.cfg;

import java.lang.reflect.AnnotatedElement;
import java.util.Map;
import javax.persistence.MappedSuperclass;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

/**
 * Some extra data to the inheritance position of a class
 *
 * @author Emmanuel Bernard
 */
public class InheritanceState {
	public InheritanceState(Class clazz) {
		this.clazz = clazz;
		extractInheritanceType();
	}

	public Class clazz;
	/** has son either mappedsuperclass son or entity son */
	public boolean hasSons = false;
	/** a mother entity is available */
	public boolean hasParents = false;
	public InheritanceType type;
	public boolean isEmbeddableSuperclass = false;
	/**
	 * used only to keep track of the root entity of a embeddedablesuperclass
	 * this root entity can vary during the process a embeddable superclass could
	 * be the superclass of several entities.
	 */
	public Class rootEntity;
	/**
	 * only defined on embedded superclasses
	 */
	public String accessType = null;
	public Boolean isPropertyAnnotated;

	private void extractInheritanceType() {
		AnnotatedElement element = clazz;
		Inheritance inhAnn = element.getAnnotation( Inheritance.class );
		MappedSuperclass mappedSuperClass = element.getAnnotation( MappedSuperclass.class );
		if ( mappedSuperClass != null ) {
			isEmbeddableSuperclass = true;
			type = inhAnn == null ? null : inhAnn.strategy();
		}
		else {
			type = inhAnn == null ? InheritanceType.SINGLE_TABLE : inhAnn.strategy();
		}
	}

	boolean hasTable() {
		return !hasParents || !InheritanceType.SINGLE_TABLE.equals( type );
	}

	boolean hasDenormalizedTable() {
		return hasParents && InheritanceType.TABLE_PER_CLASS.equals( type );
	}

	public static InheritanceState getSuperEntityInheritanceState(Class clazz, Map<Class, InheritanceState> states) {
		Class superclass = clazz;
		do {
			superclass = superclass.getSuperclass();
			InheritanceState currentState = states.get( superclass );
			if (currentState != null && ! currentState.isEmbeddableSuperclass) return currentState;
		} while (superclass != Object.class);
		return null;
	}

	public static InheritanceState getSuperclassInheritanceState(Class clazz, Map<Class, InheritanceState> states) {
		Class superclass = clazz;
		do {
			superclass = superclass.getSuperclass();
			InheritanceState currentState = states.get( superclass );
			if (currentState != null) return currentState;
		} while (superclass != Object.class);
		return null;
	}
}
