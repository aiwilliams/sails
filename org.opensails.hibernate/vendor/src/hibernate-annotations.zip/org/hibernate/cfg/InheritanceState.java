//$Id: InheritanceState.java,v 1.6 2005/10/25 22:50:20 epbernard Exp $
package org.hibernate.cfg;

import java.lang.reflect.AnnotatedElement;
import javax.persistence.AccessType;
import javax.persistence.EmbeddableSuperclass;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

/**
 * Some extra data to the inheritance position of a class
 *
 * @author Emmanuel Bernard
 */
public class InheritanceState {
	public boolean hasSons = false;
	public boolean hasParents = false;
	public boolean hasEmbeddedSuperclass = false;
	public InheritanceType type;
	public boolean isEmbeddableSuperclass = false;
	/**
	 * used only to keep track of the root entity of a embeddedablesuperclass
	 * this root entity can vary during the process a embeddable superclass could
	 * be the superclass of several entities.
	 */
	public Class rootEntity;
	/**
	 * only defined on embedded superclasses
	 */
	public AccessType accessType = null;

	public void setInheritanceType(AnnotatedElement clazz) {
		Inheritance inhAnn = clazz.getAnnotation( Inheritance.class );
		EmbeddableSuperclass superclassAnn = clazz.getAnnotation( EmbeddableSuperclass.class );
		if ( superclassAnn != null ) {
			isEmbeddableSuperclass = true;
			type = inhAnn == null ? null : inhAnn.strategy();
			accessType = superclassAnn.access();
		}
		else {
			type = inhAnn == null ? InheritanceType.SINGLE_TABLE : inhAnn.strategy();
		}
	}

	boolean hasTable() {
		return !hasParents || !InheritanceType.SINGLE_TABLE.equals( type );
	}

	boolean hasDenormalizedTable() {
		return hasParents && InheritanceType.TABLE_PER_CLASS.equals( type );
	}
}
