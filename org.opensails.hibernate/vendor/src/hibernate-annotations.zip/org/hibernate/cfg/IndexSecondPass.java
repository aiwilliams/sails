//$Id: IndexSecondPass.java,v 1.2 2005/11/11 00:03:10 epbernard Exp $
package org.hibernate.cfg;

import java.util.Map;

import org.hibernate.MappingException;
import org.hibernate.AnnotationException;
import org.hibernate.mapping.Table;
import org.hibernate.mapping.Column;

/**
 * @author Emmanuel Bernard
 */
public class IndexSecondPass implements SecondPass {
	private final Table table;
	private final String indexName;
	private final String[] columns;
	private ExtendedMappings mappings;

	public IndexSecondPass(Table table, String indexName, String[] columns, ExtendedMappings mappings) {
		this.table = table;
		this.indexName = indexName;
		this.columns = columns;
		this.mappings = mappings;
	}
	public void doSecondPass(Map persistentClasses, Map inheritedMetas) throws MappingException {
		for ( String columnName : columns) {
			Column column = table.getColumn( new Column(
					mappings.getPhysicalColumnName( columnName, table )
			) );
			if ( column == null ) {
				throw new AnnotationException(
						"@Index references a unknown column: " + columnName
				);
			}
			table.getOrCreateIndex( indexName ).addColumn( column );
		}
	}
}
