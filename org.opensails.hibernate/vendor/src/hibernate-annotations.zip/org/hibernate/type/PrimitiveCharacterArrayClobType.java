//$Id: PrimitiveCharacterArrayClobType.java,v 1.2 2005/08/08 23:35:01 oneovthafew Exp $
package org.hibernate.type;


/**
 * Map a char[] to a Clob
 *
 * @author Emmanuel Bernard
 */
public class PrimitiveCharacterArrayClobType extends CharacterArrayClobType {
	public Class returnedClass() {
		return char[].class;
	}
}
