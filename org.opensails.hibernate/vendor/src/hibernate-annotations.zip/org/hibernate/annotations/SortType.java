//$Id: SortType.java,v 1.1 2005/05/16 14:57:03 epbernard Exp $
package org.hibernate.annotations;

/**
 * Sort strategies
 *
 * @author Emmanuel Bernard
 */
public enum SortType {
	UNSORTED,
	NATURAL,
	COMPARATOR
}
