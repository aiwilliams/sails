package org.hibernate.annotations;

import static java.lang.annotation.ElementType.PACKAGE;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.ElementType.METHOD;
import java.lang.annotation.Target;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Extends {@link javax.persistence.NamedNativeQueries} to hold hibernate NamedNativeQuery
 * objects
 *
 * @author Emmanuel Bernard
 */
@Target({METHOD, TYPE, PACKAGE}) @Retention(RUNTIME)
public @interface NamedNativeQueries {
	NamedNativeQuery[] value();
}