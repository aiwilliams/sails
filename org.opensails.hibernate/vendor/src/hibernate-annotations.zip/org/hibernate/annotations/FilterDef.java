//$Id: FilterDef.java,v 1.4 2005/12/06 17:42:48 epbernard Exp $
package org.hibernate.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.ElementType.PACKAGE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Filter definition
 *
 * @author Matthew Inger
 * @author Emmanuel Bernard
 */
@Target({TYPE,PACKAGE}) @Retention(RUNTIME)
public @interface FilterDef {
	String  name();
	String defaultCondition() default "";
	ParamDef[] parameters() default {};
}
