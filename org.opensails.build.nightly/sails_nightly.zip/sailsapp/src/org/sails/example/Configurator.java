package org.sails.example;

import org.opensails.sails.oem.BaseConfigurator;

public class Configurator extends BaseConfigurator {}