package org.opensails.sails.component;

public enum HttpMethod {
	POST,
	GET,
}
