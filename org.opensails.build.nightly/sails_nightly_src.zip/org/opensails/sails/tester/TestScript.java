package org.opensails.sails.tester;

public class TestScript {
	protected final String source;
	protected final String src;
	protected final String body;

	public TestScript(String source, String src, String body) {
		this.source = source;
		this.src = src;
		this.body = body;
	}
}
