package org.opensails.sails.persist;

public interface IIdentifiable {
	Long getId();
}
