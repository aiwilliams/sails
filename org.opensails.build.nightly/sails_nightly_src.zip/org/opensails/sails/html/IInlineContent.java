package org.opensails.sails.html;

/**
 * Content for IInlineContentElements.
 * 
 * @author aiwilliams
 */
public interface IInlineContent {
	String render();
}
