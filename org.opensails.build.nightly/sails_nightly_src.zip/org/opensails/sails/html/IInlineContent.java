package org.opensails.sails.html;

/**
 * Content for IInlineContentElements.
 * 
 * @author Adam 'Programmer' Williams
 */
public interface IInlineContent {
	String render();
}
