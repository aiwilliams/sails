package org.opensails.sails.html;

public class Meta extends AbstractHtmlElement<Meta> {
	public static final String NAME = "meta";

	public Meta() {
		super(NAME);
	}
}
