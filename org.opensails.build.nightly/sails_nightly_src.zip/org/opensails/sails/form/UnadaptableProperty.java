package org.opensails.sails.form;

import org.opensails.sails.adapter.AdaptationException;
import org.opensails.sails.validation.IInvalidProperty;

public class UnadaptableProperty implements IInvalidProperty {
    public UnadaptableProperty(AdaptationException e) {
    }

    public String getProperty() {
        // TODO Auto-generated method stub
        return null;
    }
}
