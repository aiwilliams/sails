package org.opensails.sails.form;

import org.opensails.sails.model.PropertyPathException;
import org.opensails.sails.validation.IInvalidProperty;

public class InvalidProperty implements IInvalidProperty {

    public InvalidProperty(PropertyPathException e) {
        // TODO Auto-generated constructor stub
    }

    public String getProperty() {
        // TODO Auto-generated method stub
        return null;
    }

}
