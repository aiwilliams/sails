package org.opensails.sails.form;

public interface IFormElementIdGenerator {
	String idForLabel(String label);

	String idForName(String name);
}
