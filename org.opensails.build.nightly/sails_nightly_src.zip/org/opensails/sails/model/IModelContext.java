package org.opensails.sails.model;

public interface IModelContext {

    Object getModel(IPropertyPath path);

}
