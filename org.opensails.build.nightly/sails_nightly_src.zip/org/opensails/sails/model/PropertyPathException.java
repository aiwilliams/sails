package org.opensails.sails.model;

public class PropertyPathException extends RuntimeException {

}
