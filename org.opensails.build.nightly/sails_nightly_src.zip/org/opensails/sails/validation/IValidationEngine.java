package org.opensails.sails.validation;

public interface IValidationEngine {
	IValidationResult validate(Object model);
}
