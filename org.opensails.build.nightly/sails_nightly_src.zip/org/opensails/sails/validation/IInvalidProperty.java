package org.opensails.sails.validation;

public interface IInvalidProperty {
    /**
     * @return the name of the property on the target
     */
    String getProperty();
}
