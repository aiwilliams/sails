package org.opensails.sails.action;

/**
 * An action descriptor, if you will.
 * 
 * @author aiwilliams
 */
public interface IAction {
	String getName();
}