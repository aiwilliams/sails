package org.opensails.sails.annotate.filter;

public interface IFilter {
	Object before();

	void after();
}
