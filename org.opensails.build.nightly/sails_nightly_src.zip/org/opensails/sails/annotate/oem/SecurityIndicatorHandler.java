package org.opensails.sails.annotate.oem;

import org.opensails.sails.annotate.IIndicatorResolver;
import org.opensails.sails.annotate.Indicator;
import org.opensails.sails.annotate.IndicatorContext;

public class SecurityIndicatorHandler implements IIndicatorResolver {
	public Indicator resolve(IndicatorContext context) {
		return null;
	}
}